// Initialize Firebase
//The project has been deleted in firebase
//fill in your own config info 
 var firebaseConfig = {
    apiKey: "AIzaSyBkk2etPjun5mDeBJtlaMnXPhDkQQdBw3w",
    authDomain: "opendoor-a1ee5.firebaseapp.com",
    databaseURL: "https://opendoor-a1ee5.firebaseio.com",
    projectId: "opendoor-a1ee5",
    storageBucket: "opendoor-a1ee5.appspot.com",
    messagingSenderId: "153434582222",
    appId: "1:153434582222:web:0268760373da549851b49f",
    measurementId: "G-1785YZ1887"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  // firebase.analytics();


$(document).ready(function(){
  var database = firebase.database();
  var doorStatus;

  database.ref().on("value", function(snap){
    doorStatus = snap.val().doorStatus;
    if(doorStatus == 1){
      $(".doorStatus").text("The Door is on");
    } else {
      $(".doorStatus").text("The Door is off");
    }
  });

  $(".doorButton").click(function(){
    var firebaseRef = firebase.database().ref().child("doorStatus");

    if(doorStatus == 1){
      firebaseRef.set(0);
      doorStatus = 0;
    } else {
      firebaseRef.set(1);
      doorStatus = 1;
    }
  });
});
