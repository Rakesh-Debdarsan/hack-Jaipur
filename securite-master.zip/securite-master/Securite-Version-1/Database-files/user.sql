-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 04, 2020 at 09:43 AM
-- Server version: 5.5.65-MariaDB
-- PHP Version: 7.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adminTP`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(4) NOT NULL,
  `usrid` varchar(8) DEFAULT NULL,
  `uname` varchar(50) DEFAULT NULL,
  `uemail` varchar(50) DEFAULT NULL,
  `isVer` varchar(5) DEFAULT NULL,
  `otp` int(4) DEFAULT NULL,
  `checkIn` tinytext,
  `checkOut` tinytext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `usrid`, `uname`, `uemail`, `isVer`, `otp`, `checkIn`, `checkOut`) VALUES
(15, '4axPZVjX', 'Yash Aditya', 'yaadi1998@gmail.com', 'true', 0, NULL, NULL),
(36, '3PCFLEcV', 'Yash', 'yashaditya1999@gmail.com', 'false', 0, NULL, '03/05/20|05:13:41pm'),
(37, 'ruCo0Tqd', 'Ravi Ranjan Sharma', '13579rrs@gmail.com', 'true', 0, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uid` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
