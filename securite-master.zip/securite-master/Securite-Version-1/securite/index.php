<?php
/*Generating Current Date & Time*/
    date_default_timezone_set("Asia/Calcutta");
    $dateTime = date("d/m/y").'|'.date("h:i:sa");
/*Database Connection*/
    require('connection.php');

/*Getting rooms in isRes*/
    if($isRes = mysqli_query( $connection, "SELECT * FROM `rooms` WHERE isRes='false' "));

    /*Checking if room available or not using isRes1*/
    if($isRes1 = mysqli_query( $connection, "SELECT * FROM `rooms` WHERE isRes='false' "))
        $row=mysqli_fetch_assoc($isRes1);
        if($row['isRes']==='false')
            $isav=true;
        else $isav=false;

/*Registering User*/
    $c=false;/*$c is used to check if the registration is success or not*/
    if(isset($_POST['reg'])){
        $uemail=$_POST['uemail'];
        $uname=$_POST['uname'];
        /*Redirecting if the post request for room is not recieved*/
        if(isset($_POST['room'])){
            $roomOcpy=$_POST['room'];
        }
        else{
            header("Location: index.php?c=1");exit;
        }
        /*Validating name and email 
          More conditions can be checked here to make the validation perfect
        */
        if($uemail===''||$uname===''){
            header("Location: index.php?c=1");exit;
        }
/*Connecting to user Database*/
        else if($user=mysqli_query( $connection, "SELECT * FROM `user` WHERE `uemail`='$uemail'")){
            $row = mysqli_fetch_assoc($user);
            /**Validating if user exists and OTP is varified or not*/
            if($uemail===$row['uemail']&&$row['isVer']!=='true'){
                echo '<script>alert("You are already registered!\nPlease verify OTP.");</script>';
            }
            else if ($uemail===$row['uemail']&&$row['isVer']==='true')
                echo '<script>alert("You are already registered...");</script>';
            else{
                /**Random Number and userid generation */
                $otp=getNum(4);
                $getN=getName(8);
                $user=mysqli_query( $connection, "SELECT * FROM `user` WHERE `usrid`='$getN'");
                $row = mysqli_fetch_assoc($user);
                if($getN===$row['usrid']){
                    $getN=getName(8);
                }
                else;
                $sql = "INSERT INTO user (usrid, uname, uemail, otp, isVer) VALUES ('$getN','$uname', '$uemail', '$otp', 'false')";
                if ($connection->query($sql) === true){
                    foreach($roomOcpy as $room)
                        $connection->query("UPDATE `rooms` SET `usrid`='$getN',`isRes` = 'true' WHERE `rooms`.`rid` = ".$room);
                /**Php mailer */
                    $headers .= "Reply-To: Team Securite <noreply@domainName>\r\n";
                    $headers .= "Return-Path: Team Securite <noreply@domainName>\r\n";
                    $headers .= "From: Team Securite <noreply@domainName>\r\n";
                    $headers .= "Organization: Team Securite\r\n";
                    $headers .= "MIME-Version: 1.0\r\n";
                    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
                    $headers .= "X-Priority: 3\r\n";
                    $headers .= "X-Mailer: PHP".phpversion()."\r\n";
                    mail($uemail, 'Book Hotel - OTP', 'Dear '.$row['uname'].',<br><br>Thanks for Registering 😊.<br><br>Your OTP is '.$otp.'.', $headers);
                    $c=true;
                }
                else
                    echo "Error: " . $sql . "<br>" . $connection->error;
            }
        }
    }
    /**OTP generation for later verifying users */
    if(isset($_POST['verotp'])){
        $uemail=$_POST['uemail'];
        if($uemail===''){
            header("Location: index.php?c=1");exit;
        }
        else if($user=mysqli_query( $connection, "SELECT * FROM `user` WHERE `uemail`='$uemail'")){
            $row = mysqli_fetch_assoc($user);
            if($uemail===$row['uemail']&&$row['isVer']!=='true'){
                $otp=getNum(4);
                $sql = "UPDATE `user` SET `otp`='$otp' WHERE `user`.`uemail` = '$uemail'";
                if ($connection->query($sql) === true){
                    $headers .= "Reply-To: Team Securite <noreply@domainName>\r\n";
                    $headers .= "Return-Path: Team Securite <noreply@domainName>\r\n";
                    $headers .= "From: Team Securite <noreply@domainName>\r\n";
                    $headers .= "Organization: Team Securite\r\n";
                    $headers .= "MIME-Version: 1.0\r\n";
                    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
                    $headers .= "X-Priority: 3\r\n";
                    $headers .= "X-Mailer: PHP".phpversion()."\r\n";
                    mail($uemail, 'Book Hotel - OTP', 'Dear '.$row['uname'].',<br><br>Thanks for Registering 😊.<br><br>Your OTP is '.$otp.'.', $headers);
                    $c=true;
                }
                else
                    echo "Error: " . $sql . "<br>" . $connection->error;
            }
            else if ($uemail===$row['uemail']&&$row['isVer']==='true')
                echo '<script>alert("You are already verified...");</script>';
            else echo '<script>alert("You are not registered!\nPlease register first.");</script>';
        }
    }
    /**Submiting OTP */
    if(isset($_POST['subotp'])){
        $uemail=$_POST['uemail'];
        if($_POST['otp']===''){
            header("Location: index.php?c=1");exit;
        }
        else if($user=mysqli_query( $connection, "SELECT * FROM `user` WHERE `uemail`='$uemail'")){
            $row = mysqli_fetch_assoc($user);
            if($_POST['otp']===$row['otp']){
                $connection->query("UPDATE `user` SET `isVer` = 'true',`otp`=0,`checkIn`='$dateTime' WHERE `user`.`uemail` = '$uemail'");
                $headers .= "Reply-To: Team Securite <noreply@domainName>\r\n";
                $headers .= "Return-Path: Team Securite <noreply@domainName>\r\n";
                $headers .= "From: Team Securite <noreply@domainName>\r\n";
                $headers .= "Organization: Team Securite\r\n";
                $headers .= "MIME-Version: 1.0\r\n";
                $headers .= "Content-type: text/html; charset=UTF-8\r\n";
                $headers .= "X-Priority: 3\r\n";
                $headers .= "X-Mailer: PHP".phpversion()."\r\n";
                mail($uemail, 'Book Hotel - OTP', 'Dear '.$row['uname'].',<br><br>Your OTP is successfully verified 😊.<br><br>Please use the URL below to open your room from virtual key.<br>URL: http://www.domainName/securite/link.php?uid='.$row['usrid'].'<br>Your User Id is '.$row['usrid'], $headers);
                header("Location: index.php?c=done");exit;
            }
            else $c='wrong';
        }
    }
    /**Checking Out */
    if(isset($_POST['cOut'])){
        $uemail=$_POST['uemail'];
        if($uemail===''){
            header("Location: index.php?c=1");exit;
        }
        else if($user=mysqli_query( $connection, "SELECT * FROM `user` WHERE `uemail`='$uemail'")){
            $row = mysqli_fetch_assoc($user);
            if($uemail===$row['uemail']&&$row['isVer']==='true'){
                $otp=getNum(4);
                $sql = "UPDATE `user` SET `otp`='$otp' WHERE `user`.`uemail` = '$uemail'";
                if ($connection->query($sql) === true){
                    $headers .= "Reply-To: Team Securite <noreply@domainName>\r\n";
                    $headers .= "Return-Path: Team Securite <noreply@domainName>\r\n";
                    $headers .= "From: Team Securite <noreply@domainName>\r\n";
                    $headers .= "Organization: Team Securite\r\n";
                    $headers .= "MIME-Version: 1.0\r\n";
                    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
                    $headers .= "X-Priority: 3\r\n";
                    $headers .= "X-Mailer: PHP".phpversion()."\r\n";
                    mail($uemail, 'Check Out Hotel - OTP', 'Dear '.$row['uname'].',<br><br>Thanks for Staying here 😊. You can now use the OTP to Check Out<br><br>Your OTP is '.$otp.'.', $headers);
                    $c='cOut';
                }
                else
                    echo "Error: " . $sql . "<br>" . $connection->error;
            }
            else if ($uemail===$row['uemail']&&$row['isVer']!=='true')
                echo '<script>alert("You are not verified...");</script>';
            else echo '<script>alert("You are not registered!\nPlease register first.");</script>';
        }
    }
    /**Submiting Check Out OTP */
    if(isset($_POST['subCout'])){
        $uemail=$_POST['uemail'];
        if($_POST['otp']===''){
            header("Location: index.php?c=1");exit;
        }
        else if($user=mysqli_query( $connection, "SELECT * FROM `user` WHERE `uemail`='$uemail'")){
            $row = mysqli_fetch_assoc($user);
            if($_POST['otp']===$row['otp']){
                if($connection->query("UPDATE `user` SET `isVer` = 'false',`otp`=0 ,`checkOut`='$dateTime' WHERE `user`.`uemail` = '$uemail'")===true){
                        $usrid1=$row['usrid'];
                        $connection->query("UPDATE `rooms` SET `isRes` = 'false',`rkey`=NULL WHERE `rooms`.`usrid` ='$usrid1'");
                        $headers .= "Reply-To: Team Securite <noreply@domainName>\r\n";
                        $headers .= "Return-Path: Team Securite <noreply@domainName>\r\n";
                        $headers .= "From: Team Securite <noreply@domainName>\r\n";
                        $headers .= "Organization: Team Securite\r\n";
                        $headers .= "MIME-Version: 1.0\r\n";
                        $headers .= "Content-type: text/html; charset=UTF-8\r\n";
                        $headers .= "X-Priority: 3\r\n";
                        $headers .= "X-Mailer: PHP".phpversion()."\r\n";
                        mail($uemail, 'Hotel - Checked Out', 'Dear '.$row['uname'].',<br><br>You are successfully Checked Out. Happy to serve you.<br><br>Come again 😊.<br><br>', $headers);
                        header("Location: index.php");exit;
                }
            }
            else $c='wrongO';
        }
    }
    function getName($n) { 
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; 
        $randomString = ''; 
      
        for ($i = 0; $i < $n; $i++) { 
            $index = rand(0, strlen($characters) - 1); 
            $randomString .= $characters[$index]; 
        } 
      
        return $randomString; 
    }
    function getNum($n) { 
        $characters = '0123456789'; 
        $randomString = ''; 
      
        for ($i = 0; $i < $n; $i++) { 
            $index = rand(0, strlen($characters) - 1); 
            $randomString .= $characters[$index]; 
        } 
      
        return $randomString; 
    }
    $connection->close();/**Closing Connection */
?>
<!----------------------HTML---------------------->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register & Book - Rooms</title>
    <style>
    #regform{
        margin:auto;
        width:30vw;
        background-color:tomato;
        padding:5vw;
        border-radius:10px;
    }
        input{
            margin-top:2px;
            margin-bottom: 2px;
            padding:5px;
            width:100%;
            outline:none;
            border-width:0;
            border-radius: 5px;
        }
        #regform div{
            padding:2vw;
        }
        #div{
            position:fixed;
            top:80vh;
            left:25vw;
            right:25vw;
            margin:auto;
            text-align:center;
            background-color:tomato;
            border-radius:10px;
            padding:20px;
            font-size:2em;
        }
        #improper, .heading{
            width:30vw;
            margin:auto;
            text-align:center;
            background-color:lightgreen;
            border-radius:10px;
            padding:5vw;
            padding-top:1vw;
            padding-bottom:1vw;
            font-size:1.5em;
        }
        #message{
            display:block;
            color:white;
            background-color: rgba(0, 0, 0, 0.6);
            position:fixed;
            text-align:center;
            font-size:2em;
            top:25vh;
            padding:7%;
            left:25vw;
            right:25vw;
            margin:auto;
            bottom:25vh;
            border-radius: 20px;
            box-shadow: 0px 0px 20px 0px white;
            z-index:10;
        }
    </style>
</head>
<body>

    <?php
    /**Verification success message */
        if(isset($_GET['c'])) if($_GET['c']==='done')
            echo '<div id="message" onclick="'."this.style.display='none';".'">Congrats you are successfully verified.<br>Please visit your Room.😊</div><script>window.history.pushState(null, null, "index.php");</script>';
    ?>
    <div>
        <?php 
        /**Improper details message */
            if(isset($_GET['c'])){
                if($_GET['c']==='1')
                    echo '<div id="improper">Please fill the details properly</div><script>window.history.pushState(null, null, "index.php");</script>';
            }
            /**OTP validation message */
            if($c===true||$c==='wrong'){
                if($c===true) echo '<div id="improper">Your Rooms are booked successfully</div>';
                else echo '<div id="improper">Wrong OTP! Try Again</div>';
        ?>
        <div class='heading'>Register & Book - Rooms</div>
        <form id="regform" action="index.php" method="post">
            <input type="hidden" name="uemail" value="<?php echo $uemail;?>">
            <input type="text" name='otp' placeholder='Enter OTP here' autocomplete='off' required><br>
            <input type="submit" value="Submit" name='subotp'>
        </form>
        <?php
            }/**Checkout otp validation message */
            else if($c==='cOut'||$c==='wrongO'){
                if($c==='cOut') echo '<div id="improper">Check Your Mail & Enter OTP to Check Out</div>';
                else echo '<div id="improper">Wrong OTP! Try Again</div>';
        ?>
        <form id="regform" action="index.php" method="post">
            <input type="hidden" name="uemail" value="<?php echo $uemail;?>">
            <input type="text" name='otp' placeholder='Enter OTP here' autocomplete='off' required><br>
            <input type="submit" value="Check Out" name='subCout'>
        </form>
        <?php
            }/**If no rooms available */
            if($isav===false) echo '<div id="div">Sorry No rooms available</div>';
            else{
        ?>
        <div class='heading'>Register & Book - Rooms</div>
        <form id="regform" action="index.php" method="post">
            <input type="text" name='uname' placeholder='Please enter your name here' autocomplete='off' required><br>
            <input type="email" name="uemail" placeholder='Email' required><br>
            <div>Choose your Rooms:<br>
                <?php 
                /**Displaying available rooms checks in loop */
                while ($row = mysqli_fetch_assoc($isRes)){?>
                    <input style="width:auto;" type="checkbox" id="<?php echo $row['rid'];?>" name='room[]' value="<?php echo $row['rid'];?>"><label for="<?php echo $row['rid'];?>">Room No: <?php echo $row['rid'];?></label><br>
                <?php } ?>
            </div>
            <input type="submit" value="Register" name='reg'>

        </form>
        <form class='heading' action="index.php" method="post">
            <div>Already registered Verify OTP here</div><br>
            <input type="email" name="uemail" placeholder='Email' required><br>
            <input style='background-color:pink;width:auto;' type="submit" value="Verify" name='verotp'>
        </form>
        <?php } ?>
        <?php if($c!=='cOut'){?>
        <form class='heading' action="index.php" method="post">
            <div>Check Out here</div><br>
            <input type="email" name="uemail" placeholder='Email' required><br>
            <input style='background-color:pink;width:auto;' type="submit" value="Verify OTP" name='cOut'>
        </form>
        <?php } ?>
    </div>
</body>
</html>
<!----------------------------Developed by Team Securite------------------------------->