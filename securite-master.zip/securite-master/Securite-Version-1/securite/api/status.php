<?php
/*Designed for device */
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");


//Creating Array for JSON response
$response = array();


require_once("db_connect.php");

if($result = mysqli_query( $connection, "SELECT * FROM `rooms` ")){
    
    // Storing the returned array in response
    $response["rooms"] = array();

    // While loop to store all the returned response in variable
    while ($row = mysqli_fetch_assoc($result)) {
        // temperoary user array
        $rooms = array();
        $rooms["rid"] = $row["rid"];
        $rooms["isO"] = $row["isO"];

        // Push all the items 
        array_push($response["rooms"], $rooms);
    }
    // Show JSON response
    echo json_encode($response);
}
else 
{
    // If no data is found
    $response["success"] = 0;
    // Show JSON response
    echo json_encode($response);
}
$connection->close();
?>