<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    //Creating Array for JSON response
    $response = array();
    // Check if we got the field from the user
    if(!empty($_POST["setrkey"])){
        require_once("db_connect.php");
        $rkey=$_POST['rkey'];
        $url=$_POST['url'];
        if(strlen($rkey)<4 || strlen($rkey)>8){
            header("Location: $url&c=2");exit;
        }
        $rid=$_POST['rid'];
        $connection->query("UPDATE `rooms` SET `rkey` = '$rkey' WHERE `rooms`.`rid` = '$rid'");
        $connection->close();
        header("Location: $url");exit;
    }
    else if(isset($_POST['open'])){
        require_once("db_connect.php");
        $rkey=$_POST['rkey'];
        $rid=$_POST['rid'];
        $url=$_POST['url'];
        if($user=mysqli_query( $connection, "SELECT * FROM `rooms` WHERE `rid`='$rid'")){
            $row = mysqli_fetch_assoc($user);
            if($rkey===$row['rkey']){
                $connection->query("UPDATE `rooms` SET `isO` = 'open' WHERE `rooms`.`rid` = '$rid'");
                $connection->close();
                header("Location: $url");exit;
            }
            else header("Location: $url&c=1");exit;
        }
    }
    else if(isset($_POST['close'])){
        require_once("db_connect.php");
        $rkey=$_POST['rkey'];
        $rid=$_POST['rid'];
        $url=$_POST['url'];
        if($user=mysqli_query( $connection, "SELECT * FROM `rooms` WHERE `rid`='$rid'")){
            $row = mysqli_fetch_assoc($user);
            if($rkey===$row['rkey']){
                $connection->query("UPDATE `rooms` SET `isO` = 'close' WHERE `rooms`.`rid` = '$rid'");
                $connection->close();
                header("Location: $url");exit;
            }
            else header("Location: $url&c=1");exit;
        }
    }
    else if(isset($_POST['openA'])){
        require_once("db_connect.php");
        $rid=$_POST['rid'];
        $url=$_POST['url'];
        if($user=mysqli_query( $connection, "SELECT * FROM `rooms` WHERE `rid`='$rid'")){
            $row = mysqli_fetch_assoc($user);
            $connection->query("UPDATE `rooms` SET `isO` = 'open' WHERE `rooms`.`rid` = '$rid'");
            $connection->close();
            header("Location: $url");exit;
        }
    }
    else if(isset($_POST['closeA'])){
        require_once("db_connect.php");
        $rid=$_POST['rid'];
        $url=$_POST['url'];
        if($user=mysqli_query( $connection, "SELECT * FROM `rooms` WHERE `rid`='$rid'")){
            $row = mysqli_fetch_assoc($user);
            $connection->query("UPDATE `rooms` SET `isO` = 'close' WHERE `rooms`.`rid` = '$rid'");
            $connection->close();
            header("Location: $url");exit;
        }
    }
    else {
        // If required parameter is missing
        $response["success"] = 0;
        $response["message"] = "Parameter(s) are missing. Please check the request";
        //Show JSON response
        //echo json_encode($response);
    }
?>