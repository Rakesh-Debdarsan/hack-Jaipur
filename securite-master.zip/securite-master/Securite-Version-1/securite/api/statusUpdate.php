<?php
/*Designed for device */
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    //Creating Array for JSON response
    $response = array();
    // Check if we got the field from the user
    if(isset($_POST['open'])){
        require_once("db_connect.php");
        $rid=$_POST['rid'];
        if($user=mysqli_query( $connection, "SELECT * FROM `rooms` WHERE `rid`='$rid'")){
            $row = mysqli_fetch_assoc($user);
            $connection->query("UPDATE `rooms` SET `isO` = 'open' WHERE `rooms`.`rid` = '$rid'");
            $connection->close();
            exit;
        }
    }
    else if(isset($_POST['close'])){
        require_once("db_connect.php");
        $rid=$_POST['rid'];
        if($user=mysqli_query( $connection, "SELECT * FROM `rooms` WHERE `rid`='$rid'")){
            $row = mysqli_fetch_assoc($user);
            $connection->query("UPDATE `rooms` SET `isO` = 'close' WHERE `rooms`.`rid` = '$rid'");
            $connection->close();
            exit;
        }
    }
    else if(isset($_GET['open'])){
        require_once("db_connect.php");
        $rid=$_GET['rid'];
        if($user=mysqli_query( $connection, "SELECT * FROM `rooms` WHERE `rid`='$rid'")){
            $row = mysqli_fetch_assoc($user);
            $connection->query("UPDATE `rooms` SET `isO` = 'open' WHERE `rooms`.`rid` = '$rid'");
            $connection->close();
            exit;
        }
    }
    else if(isset($_GET['close'])){
        require_once("db_connect.php");
        $rid=$_GET['rid'];
        if($user=mysqli_query( $connection, "SELECT * FROM `rooms` WHERE `rid`='$rid'")){
            $row = mysqli_fetch_assoc($user);
            $connection->query("UPDATE `rooms` SET `isO` = 'close' WHERE `rooms`.`rid` = '$rid'");
            $connection->close();
            exit;
        }
    }
    else {
        // If required parameter is missing
        $response["success"] = 0;
        $response["message"] = "Parameter(s) are missing. Please check the request";
        // Show JSON response
        echo json_encode($response);
    }
?>