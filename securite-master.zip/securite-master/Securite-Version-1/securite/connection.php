<?php
$connection = new mysqli("localhost:3306", "userId", "/Password/", "/databaseName/");
if ($connection->connect_error) {
  die("Connection failed: " . $connection->connect_error);
}
?>