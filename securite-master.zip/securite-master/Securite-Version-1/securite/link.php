<?php
/**reading JSON api and Variable declaration */
    $link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']=== 'on' ? "https" : "http") . "://" .$_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
    $url=file_get_contents("https://domainName/securite/api/read.php");
    $url1=json_decode($url,true);
    $rooms=$url1['rooms'];
    $user=$url1['user'];
    $admin=$url1['admin'];
    $usrid=null;
    $id=null;
    $verifiedU=$verifiedA=null;

    /**Session start */
    $sess=session_start();
    
    /**User verification */
    if(isset($_GET['id'])) if($_GET['id']==='admin')
        $id=$_GET['id'];
    if(isset($_GET['uid'])){
        $verifiedU=false;
        $usrid=$_GET['uid'];
        foreach($user as $value){
            if($value["usrid"]===$usrid&&$value["isVer"]==='true'){
                $verifiedU=true;
                break;
            }
        }
        if($verifiedU===true){
				session_destroy();
		}
        else echo '<script>alert("Not Verified!\nPlease verify first.");</script>';
    }
    /**Admin verification */
    if(isset($_POST['pass'])){
        $verifiedA=false;
        $usrid=$_POST['uid'];
        foreach($admin as $value){
            if($value["usrid"]===$usrid&&$value["pass"]===$_POST['pass']){
                $verifiedA=true;
                break;
            }
        }
        if($verifiedA===true){
            /**Creating session */
            $_SESSION['usrid']=$usrid;
            header("Location: link.php");exit;
        }
        else {
			echo '<script>alert("Wrong Passsword!\nPlease try again.");</script>';
			session_destroy();
		}
    }
    /**Session request and logout */
    if(isset($_SESSION['usrid'])){
        $usrid=$_SESSION['usrid'];
		$verifiedA=true;
    }
    if(isset($_GET['logout'])) if($_GET['logout']==='1'){
        session_destroy();
        header("Location: link.php");exit;
    }
    /**Alerts */
    if(isset($_GET['c']))
        if($_GET['c']==='1')
            echo '<script>alert("Wrong Password!\nPlease try again.");window.history.pushState(null, null, "link.php?uid='.$usrid.'");</script>';
        else if($_GET['c']==='2')
            echo '<script>alert("Password length must be from 4 to 8 !!!\nPlease try again.");window.history.pushState(null, null, "link.php?uid='.$usrid.'");</script>';
?>

<!-----------------------------------HTML------------------------------->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Key - Link</title>
    <style>
        *{
            box-sizing:border-box;
        }
        #form{
            width:200px;
            background:tomato;
            margin:5px;
            padding:2%;
            border-radius:10px;
            display:inline-block;
        }
        .contain{
            max-width:700px;
            margin:auto;
        }
        #form div{
            display:block;
            text-align:center;
            background:white;
            margin:5px;
            border-radius:10px;
        }
        #formall{
            width:300px;
            background:tomato;
            margin:auto;
            padding:2%;
            border-radius:10px;
            display:block;
            margin-top:20px;
            margin-bottom:20px;
        }
        #formall div{
            display:block;
            text-align:center;
            background:white;
            margin:5px;
            border-radius:10px;
        }
        .head{
            text-align:center;
            background:lightgreen;
            margin:auto;
            padding:2%;
            border-radius:10px;
            max-width:700px;
            text-decoration:none;
        }
        .head a{
            text-decoration:none;
            color:white;
            background:tomato;
            padding:10px;
            border-radius:10px;
        }
        input{
            margin-top:2px;
            margin-bottom: 2px;
            padding:5px;
            width:100%;
            outline:none;
            border-width:0;
            border-radius: 5px;
        }
    </style>
</head>
<body>
        <!--Heading-->
        <p class='head'>User Room Access</p>
    <div class='contain'>
        <?php 
        /*Checking if no user request is made*/
        if($usrid!==null){ 
            /**If user is verified */
            if($verifiedU===true){
                /**Showing registered rooms in loop */
                foreach($rooms as $value){
            	if($value["usrid"]==="$usrid" &&$value["isRes"]==='true'){
                    ?>
                <!------Seting room key by user--------------->
                    <?php if($value['rkey']===null){?>
                        <form id='form' action="https://domainName/securite/api/update.php" method="post">
                            <div>Room: <?php echo $value;?></div>
                            <div>Set Your Room Key</div>
                            <input type="hidden" name="url" value='<?php echo $link.'?uid='.$usrid;?>'>
                            <input type="hidden" name="rid" value='<?php echo $value['rid'];?>'>
                            <input type="password" name="rkey" id="" placeholder='Key'>
                            <input type="submit" name='setrkey' value="Set">
                        </form>
                    <?php }
                    /**Closing room */
                    else if($value['isO']==='close'){ ?>
                        <form id='form' action="https://domainName/securite/api/update.php" method="post">
                            <div>Room: <?php echo $value;?></div>
                            <div>Enter Your Room Key</div>
                            <input type="hidden" name="url" value='<?php echo $link.'?uid='.$usrid;?>'>
                            <input type="hidden" name="rid" value='<?php echo $value['rid'];?>'>
                            <input type="password" name="rkey" id="" placeholder='Key'>
                            <input type="submit" name='open' value="Open Door">
                        </form>
                    <?php }
                    /**Opening Room */
                    else if($value['isO']==='open'){ ?>
                        <form id='form' action="https://domainName/securite/api/update.php" method="post">
                            <div>Room: <?php echo $value;?></div>
                            <div>Enter Your Room Key</div>
                            <input type="hidden" name="url" value='<?php echo $link.'?uid='.$usrid;?>'>
                            <input type="hidden" name="rid" value='<?php echo $value['rid'];?>'>
                            <input type="password" name="rkey" id="" placeholder='Key'>
                            <input type="submit" name='close' value="Close Door">
                        </form>
                    <?php }?>
        <?php   } }
            }/**If admin is loged in */
            else if($verifiedA===true){
                foreach($rooms as $value){
                    ?>
                    <?php if($value['isO']==='close'){ ?>
                        <form id='form' action="https://domainName/securite/api/update.php" method="post">
                            <div>Room: <?php echo $value;?></div>
                            <input type="hidden" name="url" value='<?php echo $link.'?id='.$usrid;?>'>
                            <input type="hidden" name="rid" value='<?php echo $value['rid'];?>'>
                            <input type="submit" name='openA' value="Open Door">
                        </form>
                    <?php }
                    else if($value['isO']==='open'){ ?>
                        <form id='form' action="https://domainName/securite/api/update.php" method="post">
                            <div>Room: <?php echo $value;?></div>
                            <input type="hidden" name="url" value='<?php echo $link.'?id='.$usrid;?>'>
                            <input type="hidden" name="rid" value='<?php echo $value['rid'];?>'>
                            <input type="submit" name='closeA' value="Close Door">
                        </form>
                    <?php }?>
        <?php   }?>
        <!---------Logout button if admin is loged in---------------->
            <p class='head'><a href="link.php?logout=1">Logout</a></p>
        <?php }
            else echo "<script>alert('Sorry, no rooms reserved for you...');</script>";
        } ?>
        </div>
        <?php
        /**Admin login block */
            if(isset($_GET['uid'])||isset($_POST['uid']));
            else if($id==='admin'&&$verifiedA===null&&$verifiedU===null){ 
                ?>
                <form id='formall' action="link.php" method="post">
                <div>Login as Admin</div>
                <input type="text" name="uid" placeholder='Enter Id'>
                <input type="password" name="pass" id="" placeholder='Enter Password'>
                <input type="submit" name='close' value="Login">
            </form>
                <?php 
            }/**User login block */
			else if($verifiedA===null&&$verifiedU===null){ 
                ?>
                <form id='formall' action="link.php" method="get">
                <div>Login as User</div>
                <input type="text" name="uid" id="" placeholder='Enter Id'>
                <input type="submit" name='close' value="Login">
            </form>
                <?php
            }/**If admin loged in then display button login as user */
            if($id==='admin'||$verifiedA===true){
                ?><p class='head'><a href="link.php?logout=1">Login as User</a></p>
            <?php 
            }/**If admin loged in then display button login as user */
            else if($id===null||$verifiedU===true){
            ?>
            <p class='head'><a href="link.php?id=admin">Login as admin</a></p>
        <?php }?>
</body>
</html>
<!----------------------------Developed by Team Securite------------------------------->