<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");


//Creating Array for JSON response
$response = array();
 
// Include data base connect class

require_once("db_connect.php");

 // Connecting to database 
 if($result = mysqli_query( $connection, "SELECT * FROM `user` ")){
    
	// Storing the returned array in response
    $response["user"] = array();
 
	// While loop to store all the returned response in variable
    while ($row = mysqli_fetch_assoc($result)) {
        // temperoary user array
        $user = array();
        $user["usrid"] = $row["usrid"];
        $user["id"] = $row["id"];
        $user["uname"] = $row["uname"];
        $user["isVer"] = $row["isVer"];
        $user["uemail"] = $row["uemail"];
		// Push all the items 
        array_push($response["user"], $user);
    }
}
 // Fire SQL query to get all data from weather
if($result = mysqli_query( $connection, "SELECT * FROM `rooms` ")){
    
	// Storing the returned array in response
    $response["rooms"] = array();
 
	// While loop to store all the returned response in variable
    while ($row = mysqli_fetch_assoc($result)) {
        // temperoary user array
        $rooms = array();
        $rooms["rid"] = $row["rid"];
        $rooms["rkey"] = $row["rkey"];
        $rooms["isO"] = $row["isO"];
        $rooms["isRes"] = $row["isRes"];
        $rooms["usrid"] = $row["usrid"];

		// Push all the items 
        array_push($response["rooms"], $rooms);
    }
    // On success
    //$response["success"] = 1;
 
    // Show JSON response
    echo json_encode($response);
}	
else 
{
    // If no data is found
	$response["success"] = 0;
    $response["message"] = "No data on weather found";
 
    // Show JSON response
    echo json_encode($response);
}
$connection->close();
?>